% Driver script for solving the 1D advection equations
%close all
clear all
warning off

Globals1D;

% Order and number of elements of polymomials used for approximation 
N = 3;
K = 10; %keep this always even
periodic =1;

%Gauss quadrature - GQ and GL -Gauss lobatto
X_intgr = 'GL' % or GL

%Mass_ matrix selection
% D - diagonal mass matrix
% C - consistent mass matrix
Mass_mat_type = 'C' 



%Computational domain
xmax =1; xmin = 0;



% Initialize solver and construct grid and etric
StartUp1D;
% Set initial conditions
u = sin(x);

% %Assembling matrices
 diag_pattern_1 = ones(K,1);
 Global_pattern_main_diag = diag(diag_pattern_1);


if Mass_mat_type == 'D'
  Global_Mass = sparse(kron(Global_pattern_main_diag,Mass));
 else
  Global_Mass = sparse(kron(Global_pattern_main_diag,Mass_GL));
 end


% flux type

alpha = 0;                                        % 0 = upwind, 1 = central
Fk = 0.5*[1 1; -1 -1] + 0.5*(1-alpha)*[1 -1; -1 1];

%Global_flux_matrix
F = sparse(Np*K,Np*K);
F(1,1) = Fk(2,2);
F(Np*K,Np*K) = Fk(1,1);
for k=1:K
    if k<K
        F(Np*k:(Np*k+1),Np*k:(Np*k+1)) = Fk;
    end
end

n = 5;
I = speye(n,n);
E = sparse(2:n,1:n-1,1,n,n);
D = E+E'-2*I;
A = kron(D,I)+kron(I,D);
Fb = zeros(Np*K,2);
if periodic == 0
    Fb(1,1) = Fk(2,1);
    Fb(Np*K,2) = Fk(1,2);
else
    F(1,Np*K) = Fk(2,1);
    F(Np*K,1) = Fk(1,2);
end


% Solve Problem
FinalTime = 1;
[u, u_entire,ub,sti1,Global_eig] = Advec1D(u,FinalTime,F,Fb);


%transport simulation
% for i = 1:size(u_entire,2)
%        figure(1)
%     plot(x(:),u_entire(:,i))
%     xlim([xmin xmax]);
%     ylim([-1 1])
%     pause(0.1);
% end    

%eigen value plots  
 figure(2)
plot(real(Global_eig), imag(Global_eig),'*');
hold on


%Dispersion and Dissipiation plots

modes_disp = zeros(length(Global_eig)/2+1,1);
modes_diss = modes_disp;
c = 1;

for i=1:size(Global_eig,1)
    if (imag(Global_eig(i))>=-1e-15)
        modes_disp(c) = imag(Global_eig(i));
        modes_diss(c) = real(Global_eig(i));
        c = c+1;
    end
end

[modes_diss,ind] = sort(-modes_diss);
modes_disp = modes_disp(ind);
modes_disp(1:end/2) = sort(modes_disp(1:end/2));
figure(3); 
plot(0:(1-0)/(size(modes_disp,1)-1):1,modes_disp);
hold on
figure(4);  plot(0:(1-0)/(size(modes_diss,1)-1):1,-modes_diss);
hold on




