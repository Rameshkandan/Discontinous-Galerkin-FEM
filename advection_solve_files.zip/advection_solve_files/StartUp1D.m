% Purpose : Setup script, building operators, grid, metric and connectivity for 1D solver.     

% Definition of constants

Globals1D; 
Np = N+1; 

% Compute basic Legendre Gauss Lobatto grid
X_gl = JacobiGL(0,0,N);


%quadrature point defintion
if X_intgr == 'GL'
    X_quad = JacobiGL(0,0,N);
    w_quad = weights_LGL(X_quad,Np);
else
    [X_quad,w_quad] = JacobiGQ(0,0,N);
    
end


 % Lagrange interpolation matrix
 L = lagr_polynomial();
 

%boundary terms in the physical domain
for k=1:K
    x_m(k) = (xmax-xmin)*(k-1)/(K) + xmin;
    x_p(k) = (xmax-xmin)* k/K + xmin;

end

 %mapping from standard 1D guass-lobatto nodes to the deiscretized physical domain nodes.
 x = ones(N+1,1)*x_m + 0.5*(X_gl+1)*(x_p-x_m);
 
 %Dispersion and dissipiation analysis terms
[Mass] = Diag_Mass_matrix();
  
 %new_mass
 Mass_GL = consistent_mass();
 
 

 

