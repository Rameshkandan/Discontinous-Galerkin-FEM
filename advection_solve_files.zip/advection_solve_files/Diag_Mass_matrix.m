function [Mass] = Diag_Mass_matrix() 


Globals1D;

  Mass = zeros(Np,Np);
 
 
for i = 1:size(L,1)
    for j = 1:size(L,1)
        for q = 1:Np
           
            %Mass matrix entry using Gauss quadrature rule: wegihted summation through 
            %all quadrature points evaluated for the function
            %l_i(x_q)*l_j(x(q)*w(q)
            Mass(i,j) = Mass(i,j) + polyval(L(i,:),X_quad(q))*polyval(L(j,:),X_quad(q))*w_quad(q);
            %Mass(i,j) = Mass(i,j) + polyval(L(i,:),X_gl(q))*polyval(L(j,:),X_gl(q))*w(q);
            %Asigning  very less values to zero
            if Mass(i,j) < 10^-5
                Mass(i,j) = 0;
                
            end
        end
        
    end
end


