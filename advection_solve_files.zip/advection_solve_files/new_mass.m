function Mass_mat = consistent_mass()

Globals1D;

if X_intgr == 'GL'
X_new = JacobiGL(0,0,Np);
w1 = weights_LGL(X_new,Np+1);
else
X_new = X_quad;
w1 = w_quad;
end

Np_1 = size(X_new,1);



Mass_mat = zeros(Np,Np);  
for i = 1:size(L,1)
    for j = 1:size(L,1)
        for q = 1:Np_1
           
            %Mass matrix entry using Gauss quadrature rule: wegihted summation through 
            %all quadrature points evaluated for the function
            %l_i(x_q)*l_j(x(q)*w(q)
            Mass_mat(i,j) = Mass_mat(i,j) + polyval(L(i,:),X_new(q))*polyval(L(j,:),X_new(q))*w1(q);
                

        end
        
    end
end


end