function w = weights_LGL(X_new,Np_1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% weights_LGL.m

% Computes the Legendre-Gauss-Lobatto weights 

%Program reference from 
% https://github.com/dealii/dealii/blob/master/source/base/quadrature_lib.cc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

alpha = 0;
beta = 0;

factor = 2.0 ^(alpha+beta+1) * gam(alpha+Np_1) * gam(beta+Np_1)/((Np_1-1)*gam(Np_1)*gam(alpha+beta+Np_1+1));

for i= 1:Np_1
    s = jacobiPoly(X_new(i),alpha, beta, Np_1-1);
    
    w(i) = factor/(s*s);
end
 w(1)  = w(1)*(beta +1);
 w(Np_1) = w(Np_1)*(alpha+1);

 return

