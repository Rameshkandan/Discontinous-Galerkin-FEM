function [u,u_entire,ub,sti1,Global_eig] = Advec1D(u, FinalTime,F,Fb)

% 
% function [u] = Advec1D(u, FinalTime)
% Purpose  : Integrate 1D advection until FinalTime starting with
%            initial the condition, u

Globals1D;

% compute time step size
xmin = min(abs(x(1,:)-x(2,:)));
CFL=0.1; dt   = CFL/(2*pi)*xmin; dt = .5*dt;
Nsteps = ceil(FinalTime/dt);
dt = FinalTime/Nsteps;
u_entire = zeros(Np*K,Nsteps+1);
u_entire(:,1) = u(:);

%for every time step
for n=1:Nsteps

%initialization of stiffness and mass matrix for every time step
sti1 = sparse(zeros(Np*K,Np*K));


%for every element
for d = 0:K-1
    
    %Evaulation of Stiffness and Mass matrix
    %Do derivative matrix 
    d_L = sparse(zeros(Np,Np));
for i = 1:size(L,1)
     k=0;     
    for j = 1:size(L,1)
        y = 0;
        %sti =0;
        %M3 = 0;
       for l = 1:Np
        if l~=j
          k = (1/(X_gl(j)-X_gl(l)));
           for m=1:Np
              if not(m==j) && not(m==l)
                k = k*(X_gl(i)-X_gl(m))/(X_gl(j)-X_gl(m));               
              end
            end
         d_L(i,j) = d_L(i,j) + k;
        end
       end
       
       %Gauss integration points
       
       for q = 1:Np
           
            %stiffness matrix entry using Gauss quadrature rule: wegihted summation through 
            %all quadrature points evaluated for the function
            %l_i(x_q)*l_j(x(q)*w(q)
            sti1(i + d*size(L,1),j + d*size(L,1)) = sti1(i + d*size(L,1),j + d*size(L,1)) + polyval(L(i,:),X_quad(q))*polyval(L(q,:),X_quad(q))*d_L(q,j)*w_quad(q); 

            
       end
       

           
    end
end

end 

    % calculate Jacobian
    Jacob = d_L*x;
    
    
    %Runge-kutta explicit time integration scheme
    ub = [sin(xmin - a*n*dt); sin(xmax - a*n*dt)];
    k1 = inv(Jacob(1,1)*Global_Mass)*(a*(sti1'-F)*u_entire(:,n) - a*Fb*ub);
   
    
    ub = [sin(xmin - a*(n+0.5)*dt); sin(xmax - a*(n+0.5)*dt)];
    k2 = inv(Jacob(1,1)*Global_Mass)*((a*sti1'- a*F)*(u_entire(:,n)+0.5*dt*k1) - a*Fb*ub);
    
    
   
    k3 = inv(Jacob(1,1)*Global_Mass)*((a*sti1'- a*F)*(u_entire(:,n)+0.5*dt*k2) - a*Fb*ub);
    
    
    ub = [sin(xmin - a*(n+1)*dt); sin(xmax - a*(n+1)*dt)];
    k4 = inv(Jacob(1,1)*Global_Mass)*((a*sti1'-a*F)*(u_entire(:,n)+dt*k3) - a*Fb*ub);
    
    
    u_entire(:,n+1) = u_entire(:,n) + dt/6*(k1+2*k2+2*k3+k4);
end

%Global eigen value
Global_eig = eig(full(inv(Global_Mass)*(sti1'-F)));

return
