function L = lagr_polynomial()

Globals1D;

L = zeros(Np,Np);

%construction of Lagrange polynomial coefficient matrix
for i = 1:Np
%polynomial generation with
% with value 1 on one nodes and the
% others to be as its roots.
    pp = poly(X_gl( (1:Np) ~= i));

%normalized
    L(i,:) = pp / polyval(pp, X_gl(i));   
end