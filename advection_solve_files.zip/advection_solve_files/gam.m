function result = gam(n)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% jacobiPoly.m

% Evaluates the gamma function

%Program reference from 
% https://github.com/dealii/dealii/blob/master/source/base/quadrature_lib.cc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
result = n-1;
i =n-2;
while i>1
    result = result* i;
    i=i-1;
end

return