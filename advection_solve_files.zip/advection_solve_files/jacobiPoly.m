function k = jacobiPoly(x,alpha,beta,n)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% jacobiPoly.m

% Evaluates the Jacobi polynomials

%Program reference from 
% https://github.com/dealii/dealii/blob/master/source/base/quadrature_lib.cc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p = zeros(n+1,1);

p(1) =1.0;
if n==0
    k = p(1);
    return 
end
p(2) = ((alpha+beta+2)*x + (alpha-beta))/2;

if n == 1
    k = p(2);
    return 
end

for i=1:n-1
    
   v  = 2*i + alpha + beta;
   a1 = 2*(i+1) * (i + alpha + beta + 1)*v;
   a2 = (v + 1) * (alpha*alpha - beta*beta);
   a3 = v*(v + 1)*(v + 2);
   a4 = 2*(i+alpha)*(i+beta) * (v + 2);
   p(i+2) = ((a2 + a3*x)* p(i+1) - a4 * p(i))/a1;
   
end
 k = p(n+1);
return
